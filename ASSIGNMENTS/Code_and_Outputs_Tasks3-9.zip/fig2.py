import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
plt.rcParams["font.family"]="serif"
plt.rcParams["font.serif"]=["Times New Roman","Liberation Serif","DejaVu Serif"]
fig,ax=plt.subplots(figsize=(7.4,5.2)); ax.set_xlim(0,100); ax.set_ylim(0,72); ax.axis("off")
def box(x,y,w,h,t,fc="white",fs=8,bold=False):
    ax.add_patch(Rectangle((x,y),w,h,fc=fc,ec="black",lw=1.2)); ax.text(x+w/2,y+h/2,t,ha="center",va="center",fontsize=fs,fontweight="bold" if bold else "normal")
# Broadcast domain A
ax.add_patch(Rectangle((1,4),52,66,fc="none",ec="black",lw=1.6,ls=(0,(1,2))))
ax.text(27,66.5,"BROADCAST DOMAIN 1",ha="center",fontsize=9,fontweight="bold")
for i,x in enumerate([4,21,38]):
    ax.add_patch(Rectangle((x,36),13,26,fc="#e6e6e6",ec="black",lw=1,ls="--"))
    ax.text(x+6.5,59,f"CD {i+1}",ha="center",fontsize=8.5,fontweight="bold")
    box(x+2,50,9,4,f"Hub {i+1}",fs=8)
    box(x+2,39,9,4.5,"8 PCs",fs=8)
    ax.plot([x+6.5,x+6.5],[50,43.5],color="black",lw=1)
    ax.plot([x+6.5,x+6.5],[36,36],color="black")
    ax.plot([x+6.5,27],[36,24],color="black",lw=1.2)
box(15,19,24,6,"24-port Switch (Layer 2)",fc="#d0d0d0",fs=8.5)
ax.text(27,14.5,"Switch ports to hubs belong to CD 1-3",ha="center",fontsize=7.5)
# link switch-router
ax.plot([39,57],[22,22],color="black",lw=1.8); ax.plot([53,57],[22,22],color="black",lw=1.8)
ax.text(48,23.5,"CD 4",ha="center",fontsize=8.5,fontweight="bold")
box(57,17.5,12,9,"Router\n(Layer 3)",fc="#bbbbbb",fs=9)
ax.text(57.5,15,"G0/0",fontsize=7.5); ax.text(64.5,15,"G0/1",fontsize=7.5)
ax.plot([69,76],[22,22],color="black",lw=1.8); ax.text(72.5,23.5,"CD 5",ha="center",fontsize=8.5,fontweight="bold")
# Broadcast domain B
ax.add_patch(Rectangle((76,4),23,66,fc="none",ec="black",lw=1.6,ls=(0,(1,2))))
ax.text(87.5,66.5,"BROADCAST\nDOMAIN 2",ha="center",va="center",fontsize=9,fontweight="bold")
box(79,18,17,8,"Switch 2\n(Layer 2)",fc="#d0d0d0",fs=8.5)
# phones
ax.plot([87.5,87.5],[26,56],color="black",lw=0.8)
for k in range(12):
    y=7+ (k//6)*0
for k in range(12):
    col=k%2; row=k//2
    y=30+row*4.8; x=79+col*10
    ax.add_patch(Rectangle((x,y),7.5,3.4,fc="white",ec="black",lw=0.7)); ax.text(x+3.75,y+1.7,f"Phone {k+1}",ha="center",va="center",fontsize=5.5)
    ax.plot([87.5,x+(7.5 if col==0 else 0)],[y+1.7,y+1.7],color="black",lw=0.5)
ax.text(87.5,10.5,"CD 6 - CD 17:\none per phone\n(12 switch ports)",ha="center",fontsize=7.5)
ax.text(50,0.5,"Total: 17 collision domains (3 + 1 + 1 + 12)    |    2 broadcast domains",ha="center",fontsize=9,fontweight="bold")
plt.savefig("fig_domains.png",dpi=200,bbox_inches="tight")
