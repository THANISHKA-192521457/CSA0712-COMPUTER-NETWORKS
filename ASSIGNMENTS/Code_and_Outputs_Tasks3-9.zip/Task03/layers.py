"""How data is wrapped by each layer at the sender and unwrapped at the receiver."""
LAYERS = [("Application", "HTTP"), ("Transport", "TCP"), ("Network", "IP"),
          ("Data link", "ETH")]

def send(message):
    pdu = message
    for layer, tag in LAYERS:
        tail = "|FCS]" if tag == "ETH" else "]"
        pdu = "[" + tag + "|" + pdu + tail
        print(f"{layer} adds {tag} -> {len(pdu)} bytes")
    return pdu

def receive(frame):
    pdu = frame
    for layer, tag in reversed(LAYERS):
        head = "[" + tag + "|"
        tail = "|FCS]" if tag == "ETH" else "]"
        assert pdu.startswith(head) and pdu.endswith(tail), f"{layer}: bad header"
        pdu = pdu[len(head):-len(tail)]
    return pdu

frame = send("GET /results")
print("on the wire:", frame)
print("delivered :", receive(frame))
print(f"overhead : {len(frame) - len('GET /results')} bytes for 12 bytes of data")
big = "x" * 1400
f2 = frame_big = None
import io, contextlib
with contextlib.redirect_stdout(io.StringIO()):
    f2 = send(big)
ov = len(f2) - 1400
print(f"1400-byte message: overhead {ov} bytes = {ov/len(f2):.2%} of the PDU; 12-byte: {28/len(frame):.2%}")
