import math
# CRC long-division trace
def trace(dividend, divisor):
    rem = list(dividend); lines=[]
    for i in range(len(dividend)-len(divisor)+1):
        if rem[i]=='1':
            before=''.join(rem)
            for j in range(len(divisor)):
                rem[i+j]='0' if rem[i+j]==divisor[j] else '1'
            lines.append((i,before,''.join(rem)))
    return lines, ''.join(rem[-(len(divisor)-1):])
l,r=trace("1101011011000","1011")
for i,b,a in l: print("shift",i,b,"->",a)
print("CRC",r)
l,r=trace("1101011011101","1011")
print("received remainder",r)
# Pattern checks
def rem(bits): 
    return trace(bits,"1011")[1]
def par(bits): return bits.count('1')%2==0
n=13
pats={"2-bit 0000000000011":"0000000000011","2-bit 7 apart 0000010000001":"0000010000001",
"3-bit 1011":"0000000001011","4-bit 1111":"0000000001111","4-bit 11101":"0000000011101","1-bit":"0000000000100"}
for k,e in pats.items():
    print(k,"weight",e.count('1'),"CRC detects:",rem(e)!="000","parity detects:",e.count('1')%2==1)
# BER
p=1e-3
pok16=(1-p)**16; print("P ok 16",pok16,"E tx",1/pok16,"bits",16/pok16,"extra delay ms",(1/pok16-1)*40, "P retx",1-pok16)
pok21=(1-p)**21; p1=21*p*(1-p)**20
print("P<=1err 21",pok21+p1,"P>=2",1-pok21-p1, "avg extra delay ms",(1-pok21-p1)*40)
# Task 3 numbers
print("small",58/70, "big",58/1458, "min-frame", 100e6/(64+20)/8, 100e6/((70+20)*8), 100e6/(84*8))
print("jumbo overhead 1500:",38/1538,"9000:",38/9038)
# BDP
print("BDP 4ms", 1e9*0.004/8, "BDP 12.6ms", 1e9*0.0126/8)
print("task1", 32+0.24+96+30, 8*(32+0.24+96+30), 32+0.24+4.8+30, 8*(32+0.24+4.8+30))
print("lora", 600*50*8, 5000/400)
print("tx 1MB buffer ms", 8e6/1e9*1000)
print("hop avgs",[sum(x)/3 for x in [(0.6,0.5,0.6),(3.1,2.9,3.4),(4.0,4.2,4.2),(11.8,11.5,12.1),(12.6,12.4,12.9)]])
print("SR W=335 buffer KB",335*1.5)
print("task12", 1265.92+16+200, 536.32+16+10)
