"""CRC error detection for frames sent between two switches."""
def mod2_div(dividend, divisor):
    rem = list(dividend)
    for i in range(len(dividend) - len(divisor) + 1):
        if rem[i] == "1":
            for j in range(len(divisor)):
                rem[i + j] = "0" if rem[i + j] == divisor[j] else "1"
    return "".join(rem[-(len(divisor) - 1):])

def encode(data, gen):
    crc = mod2_div(data + "0" * (len(gen) - 1), gen)
    return data + crc

def check(frame, gen):
    return set(mod2_div(frame, gen)) == {"0"}

GEN = "1011"
frame = encode("1101011011", GEN)
print("transmitted:", frame)
print("no error :", check(frame, GEN))
bad = frame[:4] + ("1" if frame[4] == "0" else "0") + frame[5:]
print("1-bit error:", check(bad, GEN))
burst = frame[:2] + "".join("1" if b == "0" else "0" for b in frame[2:5]) + frame[5:]
print("3-bit burst:", check(burst, GEN))

# Extra: received frame check and undetectable error pattern
print("received 1101011011101 accepted?", check("1101011011101", GEN), "remainder", mod2_div("1101011011101", GEN))
# an error pattern equal to a multiple of the generator is undetected: E = 1011 shifted
E = "0000000001011"[-len(frame):]
E = "0" * (len(frame) - 4) + "1011"
undetected = "".join("1" if a != b else "0" for a, b in zip(frame, E))
print("error pattern", E, "-> received", undetected, "accepted?", check(undetected, GEN))
E2 = "0" * (len(frame) - 7) + "1011000"
und2 = "".join("1" if a != b else "0" for a, b in zip(frame, E2))
print("error pattern", E2, "accepted?", check(und2, GEN))
# Parity 2-D
import itertools
blk = ["1101", "0110", "1011", "0001"]
rowp = [str(sum(map(int, r)) % 2) for r in blk]
colp = [str(sum(int(r[c]) for r in blk) % 2) for c in range(4)]
allp = str(sum(map(int, colp)) % 2)
print("rows", blk, "row parity", rowp, "col parity", colp, "corner", allp)
# Internet checksum
words = [0x4500, 0x0073, 0x0000, 0x4000]
s = sum(words)
while s >> 16:
    s = (s & 0xFFFF) + (s >> 16)
print("sum", hex(s), "checksum", hex(~s & 0xFFFF))
