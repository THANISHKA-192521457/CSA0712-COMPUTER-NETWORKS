import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle
plt.rcParams["font.family"]="serif"
plt.rcParams["font.serif"]=["Times New Roman","Liberation Serif","DejaVu Serif"]

# Fig 1 traffic
fig,ax=plt.subplots(figsize=(6.4,3.4))
names=["Robots","Sensors","CCTV\n(continuous)","Office","CCTV\n(5% motion)"]
vals=[32,0.24,96,30,4.8]
cols=["#222222","#555555","#222222","#555555","#999999"]
b=ax.bar(names,vals,color=cols,edgecolor="black")
for r,v in zip(b,vals): ax.text(r.get_x()+r.get_width()/2,v+1.5,f"{v} Mbps",ha="center",fontsize=9)
ax.set_ylabel("Traffic per line (Mbps)"); ax.set_ylim(0,112)
ax.set_title("Traffic per production line by source")
plt.tight_layout(); plt.savefig("fig_traffic.png",dpi=200)

# Fig 2 domains
fig,ax=plt.subplots(figsize=(7.2,4.6)); ax.set_xlim(0,100); ax.set_ylim(0,64); ax.axis("off")
def box(x,y,w,h,t,fc="white",fs=8,lw=1.2,ls="-"):
    ax.add_patch(Rectangle((x,y),w,h,fc=fc,ec="black",lw=lw,ls=ls)); ax.text(x+w/2,y+h/2,t,ha="center",va="center",fontsize=fs)
# hubs
for i,x in enumerate([2,20,38]):
    ax.add_patch(Rectangle((x-1,36),16,24,fc="#eeeeee",ec="black",ls="--",lw=1))
    box(x+2,50,10,5,f"Hub {i+1}",fs=8)
    box(x+0,38,6,4,"8 PCs",fs=7); box(x+8,38,6,4,"(8)",fs=7)
    ax.text(x+7,58,f"CD {i+1}",ha="center",fontsize=8,fontweight="bold")
    ax.plot([x+7,x+7],[50,45],color="black",lw=0.8)
    ax.plot([x+7,29],[36,30],color="black",lw=1)  # to switch (included in CD)
# switch
box(18,24,22,6,"24-port Switch (L2)\nBroadcast domain A",fs=8,fc="#dddddd")
# router
box(56,24,18,6,"Router (L3)",fs=9,fc="#cccccc")
ax.plot([40,56],[27,27],color="black",lw=1.5); ax.text(48,28.5,"CD 4",ha="center",fontsize=8,fontweight="bold")
ax.plot([74,84],[27,27],color="black",lw=1.5); ax.text(79,28.5,"CD 5",ha="center",fontsize=8,fontweight="bold")
ax.text(57,21,"G0/0",fontsize=7); ax.text(70,21,"G0/1",fontsize=7)
box(84,24,14,6,"Switch 2 (L2)\nBroadcast domain B",fs=7,fc="#dddddd")
for k in range(12):
    x=62+ (k%6)*6; y=8 if k<6 else 1
    ax.add_patch(Rectangle((x,y),5,3.5,fc="white",ec="black",lw=0.8)); ax.text(x+2.5,y+1.7,f"P{k+1}",ha="center",va="center",fontsize=6)
    ax.plot([x+2.5,91],[y+3.5,24],color="black",lw=0.4)
ax.text(66,13.5,"12 IP phones: CD 6 - CD 17 (one per switch port)",fontsize=7.5)
ax.add_patch(Rectangle((1,22),72,40,fc="none",ec="black",lw=1.2,ls=":")); ax.text(2,20,"Broadcast domain A (router G0/0 side)",fontsize=8,fontweight="bold")
ax.add_patch(Rectangle((60,-0.5),39,31.5,fc="none",ec="black",lw=1.2,ls=":"))
ax.text(1,1,"Total: 17 collision domains\n(3 hub segments + 2 router links + 12 phone links)\n2 broadcast domains",fontsize=8)
plt.savefig("fig_domains.png",dpi=200,bbox_inches="tight")
