"""Link utilisation of stop-and-wait and sliding-window protocols on different links."""
def utilisation(frame_bits, rate_bps, distance_m, window, speed=2e8):
    tx = frame_bits / rate_bps
    prop = distance_m / speed
    a = prop / tx
    return min(1, window / (1 + 2 * a)), a

links = [("Campus LAN, 200 m, 1 Gbps", 1e9, 200),
         ("City fibre, 50 km, 1 Gbps", 1e9, 50_000),
         ("Satellite, 36,000 km, 10 Mbps", 10e6, 36_000_000)]
for name, rate, dist in links:
    u1, a = utilisation(12_000, rate, dist, 1)
    u7, _ = utilisation(12_000, rate, dist, 7)
    u127, _ = utilisation(12_000, rate, dist, 127)
    print(f"{name:<31} a = {a:7.2f} stop-and-wait {u1:6.1%} "
          f"W=7 {u7:6.1%} W=127 {u127:6.1%}")

import math
# satellite smallest window
a_sat = utilisation(12_000, 10e6, 36_000_000, 1)[1]
print("Satellite smallest window:", math.ceil(1 + 2 * a_sat))
# head-office link, 400 km, 1 Gbps, 1500 B frames
tx = 12_000 / 1e9; prop = 400_000 / 2e8; a = prop / tx
W = math.ceil(1 + 2 * a)
print(f"tx {tx*1e6:.1f} us, prop {prop*1e3:.1f} ms, a {a:.2f}, stop-and-wait U {1/(1+2*a):.4%} = {1e9/(1+2*a)/1e6:.2f} Mbps, W {W}")
print("GBN seq bits:", math.ceil(math.log2(W + 1)), " SR seq bits:", math.ceil(math.log2(2 * W)))
print("SR W=64 util", min(1, 64/(1+2*a)), "throughput Mbps", min(1,64/(1+2*a))*1e3, "buffer KB", 64*1500/1000)
print("SR W=1000 buffer MB", 1000*1500/1e6)
