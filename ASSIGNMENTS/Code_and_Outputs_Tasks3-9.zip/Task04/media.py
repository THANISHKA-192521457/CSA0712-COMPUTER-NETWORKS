"""Nyquist and Shannon limits for the transmission media proposed for a campus."""
import math

def nyquist(bandwidth_hz, levels):
    return 2 * bandwidth_hz * math.log2(levels)

def shannon(bandwidth_hz, snr_db):
    snr = 10 ** (snr_db / 10)
    return bandwidth_hz * math.log2(1 + snr)

media = [("Telephone line", 3_100, 30), ("Cat6 pair", 250e6, 40),
         ("Wi-Fi 6 channel", 160e6, 25)]
for name, bw, snr in media:
    print(f"{name:<16} Shannon limit {shannon(bw, snr) / 1e6:10.2f} Mbps")
print(f"Nyquist, 3,100 Hz with 4 levels: {nyquist(3_100, 4) / 1e3:.1f} kbps")
# Extra analysis
print(f"250 MHz @ 15 dB: {shannon(250e6,15)/1e6:.2f} Mbps")
print(f"160 MHz @ 15 dB: {shannon(160e6,15)/1e6:.2f} Mbps")
snr_needed = 2 ** (56_000 / 3_100) - 1
print(f"SNR for 56 kbps on 3100 Hz: ratio {snr_needed:.0f}, {10*math.log10(snr_needed):.2f} dB")
